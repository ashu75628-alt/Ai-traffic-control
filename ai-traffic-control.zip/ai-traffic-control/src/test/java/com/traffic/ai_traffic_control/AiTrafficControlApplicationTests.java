package com.traffic.ai_traffic_control;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiTrafficControlApplicationTests {

	@Test
	void contextLoads() {
	}

}
